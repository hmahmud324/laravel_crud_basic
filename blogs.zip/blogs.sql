-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2023 at 09:49 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `name`, `email`, `password`, `image`, `created_at`, `updated_at`) VALUES
(6, 'Daniel Bowers', 'fixobeqy@mailinator.com', '$2y$10$CtwbQ.A4mbEleagxFMwsOOdDVcDI.AB4bP5mOBvXILpxLU2H3bTMW', 'uploads/blog-images/2023-10-16 (1).png', '2023-10-23 01:14:28', '2023-10-23 01:14:28'),
(7, 'Hiroko Sandoval', 'behah@mailinator.com', '$2y$10$emi5QCs0jMy.pzoCLMXW9OuFsRtRtjoSYlviHjYXl2VCSkn9o/XO6', 'uploads/blog-images/imagsgsdgsdfes.jpeg', '2023-10-23 01:42:11', '2023-10-23 01:42:11'),
(8, 'Jarrod Morse', 'latuvir@mailinator.com', '$2y$10$1H1BKbwQZDf9C4xZ0asgcu.xl6mTaCeydUVQ7IsOTIq3W4UZJE0ZC', 'uploads/blog-images/images (89).jpeg', '2023-10-23 01:42:46', '2023-10-23 01:42:46'),
(9, 'Chase Preston', 'humazod@mailinator.com', '$2y$10$hyJ2Cnoflm6juO3IVi1pleYKZLhnIeLnw/CKPFn8Ayz5Nnhqilgi2', 'uploads/blog-images/download (3).jpeg', '2023-10-23 01:43:08', '2023-10-23 01:43:08'),
(10, 'Kathleen Mosley', 'jujile@mailinator.com', '$2y$10$7gAuYo1azipTfbCezjhOzeOY2SLwCXZh3JJ2yoKfA41utk4IV2F/u', 'uploads/blog-images/shocked.jpg', '2023-10-23 01:43:47', '2023-10-23 01:43:47'),
(11, 'Brianna Walsh', 'zopotome@mailinator.com', '$2y$10$9VnwHRK.pMGbhHRXAh0jKOVMqqR5Hbdcs3lqbmVyRL4VdQ.qo90Iy', 'uploads/blog-images/1_cotton-afson-skin-print-unstitched-shalwer-kameez-three-pcs.jpeg', '2023-10-23 01:44:03', '2023-10-23 01:44:03'),
(12, 'Leilani Tyson', 'cuvas@mailinator.com', '$2y$10$p6L2tUGKxTBEpW4XZx.Tiu5bw.hUWMyPPehkUh0Nq9xil.urdHYcW', 'uploads/blog-images/download.jpg', '2023-10-23 01:44:25', '2023-10-23 01:44:25'),
(13, 'Ivor Carlson', 'vure@mailinator.com', '$2y$10$ZOI63/6vqYOmuuZpzeF3rub0n8eIuX0ae8htUupC4fyb48GVBTP8S', 'uploads/blog-images/0_CbXsycUiDp0j7Byj.jpg', '2023-10-23 01:45:03', '2023-10-23 01:45:03'),
(14, 'Avye Meyer', 'xazax@mailinator.com', '$2y$10$bWQQ.LTp/a3XA70nm28JbOQLPTc4u.Grq05KNmiscW6LhzbC4wNFm', 'uploads/blog-images/fe9fb4c565f1636fe82dfafc3d44da6a.720x900x1.jpg', '2023-10-23 01:45:29', '2023-10-23 01:45:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blogs_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
